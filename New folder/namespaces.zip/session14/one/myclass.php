<?php
	namespace one;
	class myclass{

		function test(){

			echo "This is test function in myclass one";
		}
	}

?>