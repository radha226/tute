<?php
	namespace two;
	class myclass{

		function test(){
			echo "This is tes function from myclass two";
		}
	}

?>